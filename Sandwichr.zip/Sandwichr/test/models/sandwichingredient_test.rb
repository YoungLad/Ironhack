require 'test_helper'

class SandwichingredientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
