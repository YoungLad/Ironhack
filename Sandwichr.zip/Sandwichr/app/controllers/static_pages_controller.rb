class StaticPagesController < ApplicationController
	def index
		render "index"
	end
end
